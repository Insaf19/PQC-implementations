// written by G. Brands and C.B. Roellgen in 2017

#ifndef RVB_MATH_H_INCLUDED
#define RVB_MATH_H_INCLUDED


#include "api.h"
#include "rng.h"
#include "sha3.h"
#include <stdlib.h>
#include <string.h>

#include <gmp.h>
#include "./mpfr/src/mpfr.h"
#include <stdio.h>





// define when OPEN_MP support is to be used. This is the ONLY difference between the optimized and non-optimized version.
// #define MULTITHREADED_MATRIX_MULTIPLICATION_ENABLED




/** \brief Generate a random value as an ASCII-string (hexadecimal number)
 * -----------------------------------------------------------------------
 *
 *  rnd: Pointer to the destination buffer (must exceed len by at least 1 byte in int, 3 byte in float)
 *
 *  float number is represented as "0.xxx..."
 *
 *  len: no of digits
 *
 * \return see rng.h
 *
 */
int random_int_str(char* rnd, int len);
int random_float_str(char* rnd, int len);




/** \brief Helper functions
* -------------------------
* Since most security options are defined in bits, but float precision has to be defined
* as decimal digits, we provide two helper functions to switch between the scales
*
* \param n size_t
* \return size_t
*
*/
size_t dec2bit(size_t n);

size_t bit2dec(size_t n);

struct v2
{
    mpfr_t a1;
    mpfr_t a2;
};

struct m22
{
    mpfr_t a11;
    mpfr_t a12;
    mpfr_t a21;
    mpfr_t a22;
};


/** \brief Memory allocation/deallocation functions
* -------------------------
*
* \param pV  struct v2 *  Two-dimensional vector
* \param iPrecision  int   Precision in bit
* \return void
*
*/
void init_v2(struct v2 *pV, int iPrecision);
void clear_v2(struct v2 *pV);


/** \brief Memory allocation/deallocation functions
* -------------------------
*
* \param pM  struct m22 *  2x2 matrix
* \param iPrecision  int   Precision in bit
* \return void
*
*/
void init_m22(struct m22 *pM, int iPrecision);
void clear_m22(struct m22 *pM);


/** \brief Matrix multiplication
* -------------------------
* If MULTITHREADED_MATRIX_MULTIPLICATION_ENABLED is defined, Open MP is used to execute the four multiplications and additions in four separate threads.
* If MULTITHREADED_MATRIX_MULTIPLICATION_ENABLED is NOT defined, the single-threaded version of function mult_m22_m22() is compiled.
*
* \param pMRes  struct m22 *  Holds the resulting 2x2 matrix at the end of the operation
* \param pM1  struct m22 *  First matrix
* \param pM2  struct m22 *  Second matrix
* \param iPrecision  int   Precision in bit
* \return void
*
*/
void mult_m22_m22(struct m22 *pMRes, struct m22 *pM1, struct m22 *pM2, int iPrecision);


/** \brief Power calculation
* --------------------------
* Binary power algorithm
*
* \param pMRes struct m22 *   the result
* \param pBase struct m22 *   the base
* \param e mpz_t   the exponent
* \return void
*
*/
void power_m22(struct m22 * pMRes, struct m22 *pBase, mpz_t e, int iPrecision);


/** \brief Matrix multiplication with a vector
* -------------------------
*
* \param pVRes  struct v2 *  Holds the resulting 2-dimensional vector at the end of the operation
* \param pM  struct m22 *  The matrix that is to be multiplied with the vector
* \param pV  struct v2 *  The vector that is to be multiplied with the matrix
* \param iPrecision  int   Precision in bit
* \return void
*
*/
void mult_m22_v2(struct v2 *pVRes, struct m22 *pM, struct v2 *pV, int iPrecision);


/** \brief Computation of the T polynomial
* -------------------------
*
* \param res  mpfr_t  Holds the result of the computation Tr(x) at the end of the operation
* \param x  mpfr_t  The argument
* \param r  mpz_t  The degree of the T-polynomial
* \param iPrecision  int   Precision in bit
* \return void
*
*/
void calculate(mpfr_t res, mpfr_t x, mpz_t r, int iPrecision);


#endif // RVB_MATH_H_INCLUDED


/** \brief get a random value
 * -----------------------------
 * we generate truly random 64 bit values.
 * attn: randombytes_init has to be called elsewhere before using this function

*/
int random_int_str(char* rnd, int len)
{
    const char dig[] = "0123456789abcdef";
    int ret_val, i;
    unsigned char* temp;

    temp = (unsigned char*) malloc(len / 2 + 1);
    ret_val = randombytes(temp, len / 2 + 1);
    for(i = 0; i < len; i++)
    {
        rnd[i] = dig[(temp[i / 2] >> (4 * (i % 2))) & 0x0f];
    }
    rnd[len] = '\0';
    free(temp);
    return ret_val;
}


int random_float_str(char *rnd, int len)
{
    int ret_val;
    char temp[len + 1];
    ret_val = random_int_str(temp, len);
    strcpy(rnd, "0.");
    strcat(rnd, temp);
    return ret_val;
}


/** \brief Helper functions
* -------------------------
* Since most security options are defined in bits, but float precision has to be defined
* as decimal digits, we provide two helper functions to switch between the scales
*
* \param n size_t
* \return size_t
*
*/
size_t dec2bit(size_t n)
{
    return (size_t)((double)n * 3.32192809488 + 0.5);
}

size_t bit2dec(size_t n)
{
    return (size_t)((double)n * 0.301029995 + 0.5);
}

/** \brief Memory allocation/deallocation functions
* -------------------------
*
* \param pV  struct v2 *  Two-dimensional vector
* \param iPrecision  int   Precision in bit
* \return void
*
*/
void init_v2(struct v2 *pV, int iPrecision)
{
    mpfr_init2(pV->a1, iPrecision);
    mpfr_set_d(pV->a1, 0.0, MPFR_RNDN);

    mpfr_init2(pV->a2, iPrecision);
    mpfr_set_d(pV->a2, 0.0, MPFR_RNDN);
}

void clear_v2(struct v2 *pV)
{
    mpfr_clear(pV->a1);
    mpfr_clear(pV->a2);
}


/** \brief Memory allocation/deallocation functions
* -------------------------
*
* \param pM  struct m22 *  2x2 matrix
* \param iPrecision  int   Precision in bit
* \return void
*
*/
void init_m22(struct m22 *pM, int iPrecision)
{
    mpfr_init2(pM->a11, iPrecision);
    mpfr_set_ui(pM->a11, 0, MPFR_RNDN);

    mpfr_init2(pM->a12, iPrecision);
    mpfr_set_ui(pM->a12, 0, MPFR_RNDN);

    mpfr_init2(pM->a21, iPrecision);
    mpfr_set_ui(pM->a21, 0, MPFR_RNDN);

    mpfr_init2(pM->a22, iPrecision);
    mpfr_set_ui(pM->a22, 0, MPFR_RNDN);
}

void clear_m22(struct m22 *pM)
{
    mpfr_clear(pM->a11);
    mpfr_clear(pM->a12);
    mpfr_clear(pM->a21);
    mpfr_clear(pM->a22);
}

/** \brief Matrix multiplication
* -------------------------
* If MULTITHREADED_MATRIX_MULTIPLICATION_ENABLED is defined, Open MP is used to execute the four multiplications and additions in four separate threads.
* If MULTITHREADED_MATRIX_MULTIPLICATION_ENABLED is NOT defined, the single-threaded version of function mult_m22_m22() is compiled.
*
* \param pMRes  struct m22 *  Holds the resulting 2x2 matrix at the end of the operation
* \param pM1  struct m22 *  First matrix
* \param pM2  struct m22 *  Second matrix
* \param iPrecision  int   Precision in bit
* \return void
*
*/
#ifdef MULTITHREADED_MATRIX_MULTIPLICATION_ENABLED
// matrix multiplication. The result is copied in the end to pMRes.
void mult_m22_m22(struct m22 *pMRes, struct m22 *pM1, struct m22 *pM2, int iPrecision)
{
    mpfr_t c01, c02, c11, c12, c21, c22, c31, c32;

    struct m22 res;
    init_m22(&res, iPrecision);

    mpfr_t res11, res12, res21, res22;
    mpfr_init2(res11, iPrecision);
    mpfr_init2(res12, iPrecision);
    mpfr_init2(res21, iPrecision);
    mpfr_init2(res22, iPrecision);

    #pragma omp parallel
    {
        #pragma omp sections nowait
        {
            #pragma omp section
            {
                mpfr_init2(c01, iPrecision);
                mpfr_init2(c02, iPrecision);
                //  c.a11 = a11 * m.a11 + a12 * m.a21;
                mpfr_mul(c01, pM1->a11, pM2->a11, MPFR_RNDN);
                mpfr_mul(c02, pM1->a12, pM2->a21, MPFR_RNDN);
                mpfr_add(res11, c01, c02, MPFR_RNDN);
                mpfr_clear(c01);
                mpfr_clear(c02);
            }
            #pragma omp section
            {
                mpfr_init2(c11, iPrecision);
                mpfr_init2(c12, iPrecision);
                //  c.a12 = a11 * m.a12 + a12 * m.a22;
                mpfr_mul(c11, pM1->a11, pM2->a12, MPFR_RNDN);
                mpfr_mul(c12, pM1->a12, pM2->a22, MPFR_RNDN);
                mpfr_add(res12, c11, c12, MPFR_RNDN);
                mpfr_clear(c11);
                mpfr_clear(c12);
            }
            #pragma omp section
            {
                mpfr_init2(c21, iPrecision);
                mpfr_init2(c22, iPrecision);
                //  c.a21 = a21 * m.a11 + a22 * m.a21;
                mpfr_mul(c21, pM1->a21, pM2->a11, MPFR_RNDN);
                mpfr_mul(c22, pM1->a22, pM2->a21, MPFR_RNDN);
                mpfr_add(res21, c21, c22, MPFR_RNDN);
                mpfr_clear(c21);
                mpfr_clear(c22);
            }
            #pragma omp section
            {
                mpfr_init2(c31, iPrecision);
                mpfr_init2(c32, iPrecision);
                //  c.a22 = a21 * m.a12 + a22 * m.a22;
                mpfr_mul(c31, pM1->a21, pM2->a12, MPFR_RNDN);
                mpfr_mul(c32, pM1->a22, pM2->a22, MPFR_RNDN);
                mpfr_add(res22, c31, c32, MPFR_RNDN);
                mpfr_clear(c31);
                mpfr_clear(c32);
            }
        } // #pragma omp sections nowait
    } // #pragma omp parallel

    mpfr_set(pMRes->a11, res11, MPFR_RNDN);
    mpfr_set(pMRes->a12, res12, MPFR_RNDN);
    mpfr_set(pMRes->a21, res21, MPFR_RNDN);
    mpfr_set(pMRes->a22, res22, MPFR_RNDN);

    mpfr_clear(res11);
    mpfr_clear(res12);
    mpfr_clear(res21);
    mpfr_clear(res22);

    clear_m22(&res);
}

#else

// matrix multiplication. The result is copied in the end to pMRes.
void mult_m22_m22(struct m22 *pMRes, struct m22 *pM1, struct m22 *pM2, int iPrecision)
{
    mpfr_t c1, c2;

    mpfr_init2(c1, iPrecision);
    mpfr_init2(c2, iPrecision);

    struct m22 res;
    init_m22(&res, iPrecision);

    //  c.a11 = a11 * m.a11 + a12 * m.a21;
    mpfr_mul(c1, pM1->a11, pM2->a11, MPFR_RNDN);
    mpfr_mul(c2, pM1->a12, pM2->a21, MPFR_RNDN);
    mpfr_add(res.a11, c1, c2, MPFR_RNDN);

    //  c.a12 = a11 * m.a12 + a12 * m.a22;
    mpfr_mul(c1, pM1->a11, pM2->a12, MPFR_RNDN);
    mpfr_mul(c2, pM1->a12, pM2->a22, MPFR_RNDN);
    mpfr_add(res.a12, c1, c2, MPFR_RNDN);

    //  c.a21 = a21 * m.a11 + a22 * m.a21;
    mpfr_mul(c1, pM1->a21, pM2->a11, MPFR_RNDN);
    mpfr_mul(c2, pM1->a22, pM2->a21, MPFR_RNDN);
    mpfr_add(res.a21, c1, c2, MPFR_RNDN);

    //  c.a22 = a21 * m.a12 + a22 * m.a22;
    mpfr_mul(c1, pM1->a21, pM2->a12, MPFR_RNDN);
    mpfr_mul(c2, pM1->a22, pM2->a22, MPFR_RNDN);
    mpfr_add(res.a22, c1, c2, MPFR_RNDN);

    mpfr_clear(c1);
    mpfr_clear(c2);

    mpfr_set(pMRes->a11, res.a11, MPFR_RNDN);
    mpfr_set(pMRes->a12, res.a12, MPFR_RNDN);
    mpfr_set(pMRes->a21, res.a21, MPFR_RNDN);
    mpfr_set(pMRes->a22, res.a22, MPFR_RNDN);

    clear_m22(&res);
}

#endif


/** \brief Power calculation
* --------------------------
* Binary power algorithm
*
* \param pMRes struct m22 *   the result
* \param pBase struct m22 *   the base
* \param e mpz_t   the exponent
* \return void
*
*/
void power_m22(struct m22 * pMRes, struct m22 *pBase, mpz_t e, int iPrecision)
{
    mpz_t _e;

    mpz_init2(_e, iPrecision);                                          // we don't want to destroy e. A local variable is needed to prevent that
    mpz_set(_e, e);

    struct m22 _Base;                                                   // we need to copy the base as the value would otherwise be destroyed
    init_m22(&_Base, iPrecision);
    mpfr_set(_Base.a11, pBase->a11, MPFR_RNDN);
    mpfr_set(_Base.a12, pBase->a12, MPFR_RNDN);
    mpfr_set(_Base.a21, pBase->a21, MPFR_RNDN);
    mpfr_set(_Base.a22, pBase->a22, MPFR_RNDN);

    struct m22 res;
    init_m22(&res, iPrecision);
    mpfr_set_ui(res.a11, 1, MPFR_RNDN);
    mpfr_set_ui(res.a22, 1, MPFR_RNDN);

    while(mpz_cmp_si(_e, 0) != 0)
    {
        if(mpz_tstbit(_e, 0))
        {
            mult_m22_m22(&res, &res, &_Base, iPrecision);
        }//endif
        mult_m22_m22(&_Base, &_Base, &_Base, iPrecision);
        mpz_fdiv_q_2exp(_e, _e, 1);
    } // while (e != 0)

    mpfr_set(pMRes->a11, res.a11, MPFR_RNDN);
    mpfr_set(pMRes->a12, res.a12, MPFR_RNDN);
    mpfr_set(pMRes->a21, res.a21, MPFR_RNDN);
    mpfr_set(pMRes->a22, res.a22, MPFR_RNDN);

    clear_m22(&_Base);
    clear_m22(&res);

    mpz_clear(_e);
} // end function


/** \brief Matrix multiplication with a vector
* -------------------------
*
* \param pVRes  struct v2 *  Holds the resulting 2-dimensional vector at the end of the operation
* \param pM  struct m22 *  The matrix that is to be multiplied with the vector
* \param pV  struct v2 *  The vector that is to be multiplied with the matrix
* \param iPrecision  int   Precision in bit
* \return void
*
*/
void mult_m22_v2(struct v2 *pVRes, struct m22 *pM, struct v2 *pV, int iPrecision)
{
    mpfr_t c1, c2;

    mpfr_init2(c1, iPrecision);
    mpfr_init2(c2, iPrecision);

    struct v2 res;
    init_v2(&res, iPrecision);

    //  res.a1 = a11 * v.a1 + a12 * v.a2;
    mpfr_mul(c1, pM->a11, pV->a1, MPFR_RNDN);
    mpfr_mul(c2, pM->a12, pV->a2, MPFR_RNDN);
    mpfr_add(res.a1, c1, c2, MPFR_RNDN);

    //  res.a2 = a21 * v.a1 + a22 * v.a2;
    mpfr_mul(c1, pM->a21, pV->a1, MPFR_RNDN);
    mpfr_mul(c2, pM->a22, pV->a2, MPFR_RNDN);
    mpfr_add(res.a2, c1, c2, MPFR_RNDN);

    mpfr_clear(c1);
    mpfr_clear(c2);

    mpfr_set(pVRes->a1, res.a1, MPFR_RNDN);
    mpfr_set(pVRes->a2, res.a2, MPFR_RNDN);

    clear_v2(&res);
}


/** \brief Computation of the T polynomial
* -------------------------
*
* \param res  mpfr_t  Holds the result of the computation Tr(x) at the end of the operation
* \param x  mpfr_t  The argument
* \param r  mpz_t  The degree of the T-polynomial
* \param iPrecision  int   Precision in bit
* \return void
*
*/void calculate(mpfr_t res, mpfr_t x, mpz_t r, int iPrecision)
{
    mpfr_t two, two_times_x;
    mpfr_init2(two, iPrecision);
    mpfr_set_ui(two, 2, MPFR_RNDN);
    mpfr_init2(two_times_x, iPrecision);
    mpfr_mul(two_times_x, x, two, MPFR_RNDN);

    struct m22 m;
    init_m22(&m, iPrecision);

    struct v2 v;
    init_v2(&v, iPrecision);

    mpfr_set_d(m.a11, 0.0, MPFR_RNDN);
    mpfr_set_d(m.a12, 1.0, MPFR_RNDN);
    mpfr_set_d(m.a21, -1.0, MPFR_RNDN);
    mpfr_set(m.a22, two_times_x, MPFR_RNDN);

    power_m22(&m, &m, r, iPrecision);
    mpfr_set_ui(v.a1, 1, MPFR_RNDN);
    mpfr_set(v.a2, x, MPFR_RNDN);
    mult_m22_v2(&v, &m, &v, iPrecision);

    mpfr_set(res, v.a1, MPFR_RNDN);

    clear_v2(&v);
    clear_m22(&m);
    mpfr_clear(two);
    mpfr_clear(two_times_x);
}







//! Public values starting with many 9-digits after the dot can be used for an attack.
static const char forbidden_argument[] = ".9999999999";


#if CRYPTO_BYTES == 32

#define RANDOM_INT_STR_SIZE 83
#define RANDOM_FLOAT_STR_SIZE 165
#define FLOAT_INTERNAL 2048
#define INT_SIZE 512
#define PUBLIC_KEYSIZE 250


#elif CRYPTO_BYTES == 48

#define RANDOM_INT_STR_SIZE 124
#define RANDOM_FLOAT_STR_SIZE 250
#define FLOAT_INTERNAL 3072
#define INT_SIZE 768
#define PUBLIC_KEYSIZE 375

#elif CRYPTO_BYTES == 64

#define RANDOM_INT_STR_SIZE 165
#define RANDOM_FLOAT_STR_SIZE 330
#define FLOAT_INTERNAL 4096
#define INT_SIZE 1024
#define PUBLIC_KEYSIZE 500

#endif


void make_new_common(char* common)
{
    char* unwanted[] = {".99" , ".50" , ".00"};
    char temp[80];
    int ready = 0;
    mpfr_t x;
    mpfr_init2(x, FLOAT_INTERNAL);
    while(ready == 0)
    {
        random_float_str(common, RANDOM_FLOAT_STR_SIZE);
        mpfr_set_str(x, common, 16, MPFR_RNDN);
        sprintf(temp, "%s%dRNf", "%.", 2 * CRYPTO_SECRETKEYBYTES - 20);
        mpfr_sprintf(common, temp, x, GMP_RNDN);

        ready = 1;
        for(int i = 0; i < 3; i++)
        {
            if(strstr(common, unwanted[i]) != 0)
            {
                ready = 0;
                break;
            }
        }
    }
    mpfr_clear(x);
}


int make_key_pair(unsigned char *pk, unsigned char *sk, char const* cv)
{
    mpz_t r;
    mpfr_t x, y;
    char temp[80];
    char buf[CRYPTO_PUBLICKEYBYTES] ;
    char common[CRYPTO_PUBLICKEYBYTES];
    int ret_val = 0;

    if(cv == 0)
    {
        make_new_common(common);
    }
    else
    {
        strcpy(common, cv);
    }

    mpz_init2(r, INT_SIZE);                  // r, size in bit
    ret_val = random_int_str(buf, RANDOM_INT_STR_SIZE); // random as hex bytes
    ret_val = mpz_set_str(r, buf, 16);                  // init number
    mpz_get_str(buf, 10, r);                            // and get string
    memcpy(sk, buf, strlen(buf) + 1);

    mpfr_init2(x, FLOAT_INTERNAL);
    mpfr_init2(y, FLOAT_INTERNAL);
    mpfr_set_str(x, common, 10, MPFR_RNDN);
    calculate(y, x, r, FLOAT_INTERNAL);
    sprintf(temp, "%s%dRNf", "%.", PUBLIC_KEYSIZE);
    mpfr_sprintf((char*)pk, temp, y, GMP_RNDN);
    strcpy((char*)&pk[strlen((char*)pk) + 1], common);

    mpz_clear(r);
    mpfr_clear(x);
    mpfr_clear(y);
    return ret_val;
}


int crypto_kem_keypair(unsigned char *pk, unsigned char *sk)
{
    return make_key_pair(pk, sk, 0);
}



int shared_secret(unsigned char *out, const char* public_val, const char *secret_key)
{
    void (*sha)(void*);
    mpz_t r;
    mpfr_t x, y;
    sha3_context c;
    char temp[80];
    char raw[CRYPTO_PUBLICKEYBYTES];
    unsigned char* hsh;

    switch(CRYPTO_BYTES)
    {
        case 32 :
            sha = &sha3_Init256;
            break;
        case 48:
            sha = &sha3_Init384;
            break;
        case 64:
            sha = &sha3_Init512;
            break;
        default:
            return -1;
            break;
    }

    mpz_init2(r, INT_SIZE);
    mpz_set_str(r, secret_key, 10);

    mpfr_init2(x, FLOAT_INTERNAL);
    mpfr_init2(y, FLOAT_INTERNAL);
    mpfr_set_str(x, public_val, 10, MPFR_RNDN);
    calculate(y, x, r, FLOAT_INTERNAL);
    sprintf(temp, "%s%dRNf", "%.", CRYPTO_SECRETKEYBYTES+10);
    mpfr_sprintf(raw, temp, y, GMP_RNDN);

    if(strstr(raw, forbidden_argument) != 0)
    {
        return RVB_INVALID_PUBLIC;
    }

    sha(&c);
    sha3_Update(&c, raw, CRYPTO_SECRETKEYBYTES);
    hsh = (unsigned char*)sha3_Finalize(&c);
    memcpy(out, hsh, CRYPTO_BYTES);

    mpz_clear(r);
    mpfr_clear(x);
    mpfr_clear(y);

    return 0;
}





int crypto_kem_enc(unsigned char *ct, unsigned char *ss, const unsigned char *pk)
{
    char t_sk[CRYPTO_SECRETKEYBYTES];
    unsigned char shared[CRYPTO_BYTES];
    int i;

    make_key_pair(&ct[CRYPTO_BYTES], (unsigned char*)t_sk, (char*)&pk[strlen((char*)pk)+1]);
    i = shared_secret(shared, (char*)pk, (char*)t_sk);
    if(i < 0) { return i; }

    for(i = 0; i <  CRYPTO_BYTES;   i++)
    {
        ct[i] = ss[i] ^ shared[i];
    }
    return 0;
}




int crypto_kem_dec(unsigned char *ss, const unsigned char *ct, const unsigned char *sk)
{
    unsigned char shared[CRYPTO_BYTES];
    int i;

    i = shared_secret(shared, (char*)&ct[CRYPTO_BYTES], (char*)sk);
    if(i < 0) { return i; }

    for(i = 0; i <  CRYPTO_BYTES;   i++)
    {
        ss[i] = ct[i] ^ shared[i];
    }

    return 0;
}




